<?php include('session.php'); ?>
<?php include('header.php'); ?>
<body>
<div id="wrapper">
<?php include('navbar.php'); ?>
<div style="height:50px;"></div>
<div id="page-wrapper">
<div class="container-fluid">
<div style="height:40px;"></div>
	<a href="https://ibb.co/L1STFxg"><img src="https://i.ibb.co/7Kv3fnp/LOGO-UPB-NEW-1.png" alt="LOGO-UPB-NEW-1" border="0"></a>
</div>
</div>
</div>
<?php include('script.php'); ?>
<?php include('modal.php'); ?>
</body>
</html>